// Arduino Opta WiFi: controle original da mesa + telemetria JSON HTTP SCOMPTEC.
#include "MesaControl.h"

void setup() { mesaSetup(); }

void loop() {
  mesaLoop();
  // A comunicação HTTP roda em tarefa separada do controle da mesa.
  // Mantida a pausa de 1 ms existente no ZIP.
  // Os tempos de classificacao/atuacao continuam definidos em MesaControl.cpp.
  delay(1);
}
