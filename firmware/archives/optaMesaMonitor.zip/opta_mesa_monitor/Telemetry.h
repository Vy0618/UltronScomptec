#pragma once
#include "TelemetryModel.h"

void telemetryBegin();
void telemetryPublish(const MesaSnapshot& snapshot);
