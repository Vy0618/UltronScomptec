# Mesa Opta WiFi — telemetria JSON/HTTP

Este é o firmware ativo da edição Wi-Fi. Consulte [INTEGRACAO_OPTA.md](../../INTEGRACAO_OPTA.md) para configuração de rede e inicialização.

- Abra opta_mesa_monitor.ino com todos os .cpp/.h desta pasta.
- Plataforma Arduino Mbed OS Opta Boards **4.6.0**; biblioteca **ArduinoJson 7.4.2**. Usa `WiFi.begin()` do core Mbed, sem APIs específicas do ESP32.
- Controle, pinos e tempos do ZIP preservados: I1 diagnóstico; I2/I3/I4 altura em LOW; I5 metal em HIGH; I6/I7 ocupação. O1 esteira, O2 queda1, O3 queda2.
- Tempos: debounce20ms, altura livre40ms, janela metal500ms, queda1 3000ms, queda2 3500ms, reto2500ms, timeoutaltura4000ms e rampacheia1700ms.
- MesaControl.cpp publica uma cópia dos sinais após atualizarControle(); a tarefa de rede envia essa cópia sem bloquear o loop de controle.
- Telemetry.cpp envia snapshots periódicos de 1 s e registra também mudanças de estado, falha, rampas e contadores. A fila em RAM tem 16 leituras mais uma pendente; excesso/idade de 15 s são descartados e contados em `extra_signals.amostras_descartadas` e no Serial. Não há recuperação integral de interrupções longas nem fila persistente.
- Config.h mantém defaults `maker` / `12345678` e um host placeholder. `opta_secrets.h` opcional pode definir `ULTRON_BACKEND_HOST`, `ULTRON_WIFI_SSID`, `ULTRON_WIFI_PASSWORD` e `ULTRON_DEVICE_API_KEY`; execute `tools/configurar-rede.ps1` na raiz para gerar a configuração local. Não assuma que o IPv4 anterior continua válido.
- O contrato JSON mantém compatibilidade com a API; consulte a documentação principal para as correções de backend e frontend desta rodada.
- Sem medições analógicas inventadas, sem emergência falsa, sem controle remoto da mesa.
- A rede usa HTTP local sem TLS e deve ficar restrita ao hotspot de protótipo. O envio roda em tarefa separada para preservar o loop de controle.

O primeiro registro fornece o identificador de boot, mantido até reiniciar fisicamente o Opta. Quedas de Wi-Fi e novos registros não mudam eventos pendentes. Um HTTP 404 refaz o cadastro pelo MAC; retries conservam o mesmo JSON, `event_id`, `boot_id` e `timestamp`. Respostas truncadas têm resultado incerto e também repetem o evento. Erros 408/429/5xx são temporários; outros 4xx descartam explicitamente a leitura e registram diagnóstico. A API deduplica pelo evento dentro de cada dispositivo.

O timestamp UTC de captura é **estimado**, usando `server_time_unix` do registro mais o relógio monotônico do Opta e metade do tempo da requisição. Não depende de NTP. A precisão depende do relógio do servidor, resolução em segundos e assimetria/latência da rede; não é sincronização industrial. Recalibrar em outro registro não altera o payload de uma leitura já pendente. O acumulador suporta o rollover de `millis()`.

A idade de 15 s é verificada antes de iniciar cada envio e nas iterações da tarefa. Uma chamada já em andamento pode terminar depois desse prazo. O framing da resposta tem timeout total de 4 s; associação Wi-Fi/DNS/conexão TCP também dependem dos timeouts internos do driver Mbed. Eles ocorrem na tarefa de rede e precisam de ensaio físico; não são um prazo de tempo real garantido.

As transições de estado são observadas a cada loop, mas pulsos brutos dos sensores continuam sendo snapshots e não constituem um gravador de todos os flancos elétricos. Rampa cheia é ocupação prolongada exibida nos sinais da mesa; não foi convertida em emergência nem modificou o controle físico.

## Compilação e testes sem hardware (Windows)

As dependências locais desta cópia ficam em `.tools` e os resultados em `.build`, fora do firmware distribuído. O runner não instala nada automaticamente.

1. Use Arduino CLI 1.5.1 (também incluído no Arduino IDE 2) e configure `.tools/arduino-cli.yaml` com `directories.data`, `directories.downloads` e `directories.user` apontando respectivamente para `.tools/arduino-data`, `.tools/arduino-downloads` e `.tools/arduino-user` nesta cópia.
2. Instale com esse arquivo de configuração:

```powershell
arduino-cli core update-index --config-file .tools/arduino-cli.yaml
arduino-cli core install arduino:mbed_opta@4.6.0 --config-file .tools/arduino-cli.yaml
arduino-cli lib install ArduinoJson@7.4.2 --config-file .tools/arduino-cli.yaml
```

3. Para os testes C++ de host, extraia [Zig 0.13.0 para Windows x86_64](https://ziglang.org/download/0.13.0/zig-windows-x86_64-0.13.0.zip) em `.tools/zig/zig-windows-x86_64-0.13.0`, ou informe `-ZigPath`.
4. Na raiz, execute:

```powershell
powershell -ExecutionPolicy Bypass -File firmware/testar-firmware.ps1
# Somente testes de host:
powershell -ExecutionPolicy Bypass -File firmware/testar-firmware.ps1 -HostOnly
```

O script compila/executa o `MesaControl.cpp` real com GPIO/tempo simulados; testa a mesma lógica C++ de fila, identidade, retry, relógio, serialização e framing HTTP usada no Opta; gera `.build/firmware/telemetry-fixtures.json` com JSON real para os testes da API; e compila o alvo `arduino:mbed_opta:opta`. A compilação usa temporariamente uma letra livre U:–Z: para evitar o limite de caminhos do GCC 7 no Windows e remove o mapeamento ao terminar. Nenhum upload é executado.

Os testes de host não validam polaridade elétrica, rádio/driver Wi-Fi, temporização RTOS, relés, sensores ou segurança da instalação. Esses itens continuam dependendo de bancada física.

O loop mantém a pausa de1ms do ZIP. Isso não garante comportamento temporal idêntico no hardware: compare as três categorias e teste com servidor indisponível antes de operar.

A referência original permanece em ../reference/mesa_opta_v2_original.ino. O JSON e extra_signals.mesa seguem o contrato da aplicação.
